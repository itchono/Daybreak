import java.util.ArrayList;
import java.util.List;

class Form {
	// Base object for forms which everything should be layered upon
	SquareSpace parent;
	
	List<Component> components = new ArrayList<Component>();

	int dispC, x, y, w, h;
	Form(SquareSpace p, int c, int x, int y, int w, int h){
		parent = p;
		dispC = c;
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
	}
	
	public void createGrid(int x, int y, int gridW, int gridH, int cellSize, int gapSpace) {
		components.add(new Grid(parent, x, y, gridW, gridH, cellSize, gapSpace));
	}

	public void createButton() {
		components.add(new MenuButton(parent, "Start", 500, 200, 100, 50));
	}

	public void createShop() {
		components.add(new Shop(parent, 920, 10, 200, 700));
	}
	
	
	
	public void clickForm() {
		for (Component c : components) 
			c.click();
	}

	public void drawComponents() {
		for (Component c : components) 
			c.draw();
	}
	
	public void fillDraw() {
		
	}
}

class MainMenu extends Form {

	MainMenu(SquareSpace p, int c, int x, int y, int w, int h) {
		super(p, c, x, y, w, h);
		
	}
	
}

class GameForm extends Form {

	String msg;

	GameForm(SquareSpace p, int c, int x, int y, int w, int h) {
		super(p, c, x, y, w, h);
		parent = p;
		dispC = c;
		
	}
	public void fillDraw() {
		// Onetime setup for BG
		parent.fill(dispC);
		parent.rect(x, y, w, h);
		parent.fill(parent.color(0));
		parent.textSize(32);
		parent.text("Battle Squares. Click to Play.", 20, 60);
		// Draw itself
	}

}

