
import java.util.ArrayList;
import java.util.List;

import processing.core.*;

public class SquareSpace extends PApplet {

	Form[] forms = new Form[10];

	int activeForm = -1;
	// used in conjunction with array
	
	boolean superDraw;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PApplet.main("SquareSpace");
	}

	public void settings() {
		setSize(1280, 720);
	}

	public void setup() {
		background(200, 200, 200);

		forms[0] = new GameForm(this, color(255, 255, 250), 10, 10, 900, 700);
		forms[0].createGrid(20, 100, 20, 10, 40, 0);
		forms[0].createShop();

		forms[1] = new Form(this, color(200, 200, 200), 0, 0, width, height);
		forms[1].createButton();

		activeForm = 1;
		// Menu

		fill(255, 255, 255);

		// fill in current form

		superDraw = true;
		forms[activeForm].fillDraw();
		
		draw();
		superDraw = false;
		
	}

	public void draw() {
		forms[activeForm].drawComponents();
	}

	public void mouseClicked() {

		forms[activeForm].clickForm();

	}

	public void formTransition(int newForm) {
		activeForm = newForm;
		
		background(200, 200, 200);

		textAlign(LEFT);

		superDraw = true;
		forms[activeForm].fillDraw();
		draw();
		superDraw = false;

	}

}



class Occupant {
	// Base class for units and buildings

}
