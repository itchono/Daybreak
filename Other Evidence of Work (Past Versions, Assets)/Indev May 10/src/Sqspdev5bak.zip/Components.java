import processing.core.PConstants;
import processing.core.PImage;

// Components

// Superclass

class Component {
	int x, y, w, h;

	SquareSpace parent;

	int[][] colours;
	// 2D array; colours for each state, and a highlight layer
	// i.e. [0][0] is base colour for state 0, while [1][0] is highlight colour for
	// state 0

	// Same infrastructure will be used in image textures for actual game

	Component(SquareSpace parent, int x, int y, int w, int h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.parent = parent;

	}

	public boolean containsMouse() {
		return (parent.mouseX > x && parent.mouseX < x + w && parent.mouseY > y && parent.mouseY < y + h);
	}

	public boolean mouseProximity(int range) {
		return (parent.mouseX > x - range && parent.mouseX < x + range + w && parent.mouseY > y - range
				&& parent.mouseY < y + range + h);
	}

	public void draw() {

		parent.rect(x, y, w, h);
	}

	public void click() {

	}
}

class Grid extends Component {
	// Invisible object with no set dimensions; used as frame for square cells

	int cellSize, gapSpace;

	Cell[][] squares;

	// Constructor
	Grid(SquareSpace p, int x, int y, int w, int h, int cellSize, int gapSpace) {
		super(p, x, y, w, h);
		this.cellSize = cellSize;
		this.gapSpace = gapSpace;

		// Initialize squares

		squares = new Cell[w][h];

		for (int gridX = 0; gridX < w; gridX++) {
			for (int gridY = 0; gridY < h; gridY++) {
				squares[gridX][gridY] = new Cell(parent, cellSize * (gridX + gapSpace) + x,
						cellSize * (gridY + gapSpace) + y, gridX, gridY, cellSize, cellSize);
				// Applies offset of the grid component itself to each square
			}
		}
	}

	public void draw() {
		// mirrors draw command to all squares within a certain mouse proximity
		int xValue = (int) Math.floor((parent.mouseX - x) / (double) (cellSize + gapSpace));
		int yValue = (int) Math.floor((parent.mouseY - y) / (double) (cellSize + gapSpace));

		if (parent.superDraw) {
			// Draw all
			for (int gx = 0; gx < w; gx++) {
				for (int gy = 0; gy < h; gy++)
					squares[gx][gy].draw();
			}
		}

		// NEW EFFICIENT DRAWING ALGORITHM

		// Draws within 2 square radius
		else {
			int proximity = 2;
			for (int gridX = (xValue - proximity < 0 ? 0 : xValue - proximity); gridX < (xValue + proximity > w ? w : xValue + proximity); gridX++) {
				for (int gridY = (yValue - proximity < 0 ? 0 : yValue - proximity); gridY < (yValue + proximity > h ? h : yValue + proximity); gridY++)
					squares[gridX][gridY].draw();
			}
		}

	}

	public void click() {

		// Optimizing clicking process

		int xValue = (int) Math.floor((parent.mouseX - x) / (double) (cellSize + gapSpace));
		int yValue = (int) Math.floor((parent.mouseY - y) / (double) (cellSize + gapSpace));

		System.out.println(xValue + "," + yValue);
		if (xValue < w && xValue >= 0 && yValue < h && yValue >= 0)
			squares[xValue][yValue].state = squares[xValue][yValue].state == 0 ? 1 : 0;
	}

}

class Cell extends Component {
	// Square objects drawn on screen, can contain occupants, and are the basis of
	// interaction
	int state, gridX, gridY, unitID;

	PImage[] unitImg;

	// x pos, y pos, side length, state variable

	Cell(SquareSpace p, int px, int py, int gx, int gy, int w, int h) {
		super(p, px, py, w, h);
		colours = new int[][] { { p.color(100, 100, 200), p.color(65, 242, 183) },
				{ p.color(150, 150, 250), p.color(132, 237, 202) } };
		gridX = gx;
		gridY = gy;
		unitImg = new PImage[] { parent.loadImage("ElementanTank.png"), parent.loadImage("EquanosTank.png") };
		// TODO NEVER EVER EVER EVER EVER DRAW WITH AN IMAGE IN SETUP
	}

	public void draw() {
		// only updates near button
		parent.fill(colours[this.containsMouse() ? 1 : 0][state]);

		parent.rect(x, y, w, h);

		parent.image(unitImg[state], x + 5, y + 5, w - 10, h - 10);

		parent.fill(255);
		parent.textSize(12);
		parent.text((String) (gridX + "," + gridY), x + 10, y + 20);

	}

}

class MenuButton extends Component {
	String text;

	MenuButton(SquareSpace p, String s, int x, int y, int w, int h) {
		super(p, x, y, w, h);
		text = s;
	}

	public void draw() {
		// try to only change on update

		if (this.mouseProximity(50) || parent.superDraw) {
			parent.fill(parent.color(200, 200, 200));
			parent.rect(x, y, w, h);

			parent.textAlign(PConstants.CENTER, PConstants.CENTER);
			parent.fill(parent.color(0));
			parent.text(text, x + w / 2, y + h / 2);
		}

	}

	public void click() {
		if (this.containsMouse())
			parent.formTransition(0);
	}

}

class Shop extends Component {

	ShopItem[] shops;

	Shop(SquareSpace parent, int x, int y, int w, int h) {
		super(parent, x, y, w, h);

	}

}

class ShopItem extends Component {

	ShopItem(SquareSpace parent, int x, int y, int w, int h) {
		super(parent, x, y, w, h);

	}

}
